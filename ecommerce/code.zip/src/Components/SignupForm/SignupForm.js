import React, { useState } from 'react'
import "./SignupForm.css"
import { Link } from 'react-router-dom'
import { Container, Row } from 'react-bootstrap'

function SignupForm() {
    const [phoneState, setPhoneState] = useState(false)

    return (
        <section className='signup_form_container'>
            <Container>
                <Row>
                    <div className='col-lg-6 offset-lg-3' >
                        <h2 >Register</h2>
                        <form>
                            {phoneState ?
                                <>
                                    <label >Phone*</label>
                                    <input type='number' />
                                </>
                                :
                                <>
                                    <label >Email address*</label>
                                    <input type='email' />
                                </>
                            }

                            <br />
                            <label>Password *</label>
                            <input type='password' />
                            <br />
                            <label>Confirm Password *</label>
                            <input type='password' />
                            <br />
                            {
                                phoneState ?

                                    <p onClick={() => setPhoneState(false)} className='login_state'>Register by email address</p>

                                    :
                                    <p onClick={() => setPhoneState(true)} className='login_state'>Register by phone</p>


                            }
                            <br />

                            <button type='submit'>REGISTER</button>
                        </form>
                        <div className='login'>
                            <Link to="/login">or Login</Link>
                        </div>
                    </div>
                </Row>
            </Container>
        </section>)
}

export default SignupForm