import React from 'react'
import manImg from "../../assists/img/banner-1.jpg"
import womanImg from "../../assists/img/banner-2.jpg"
import childImg from "../../assists/img/banner-3.jpg"

import "./Catigouries.css"
function Catigouries() {
    return (
        <div>
            <div className="banner-section spad">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-lg-4">
                            <div className="single-banner">
                                <img src={manImg} alt="" />
                                <div className="inner-text">
                                    <h4>Men’s</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="single-banner">
                                <img src={womanImg} alt="" />
                                <div className="inner-text">
                                    <h4>Women’s</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="single-banner">
                                <img src={childImg} alt="" />
                                <div className="inner-text">
                                    <h4>Kid’s</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    )
}

export default Catigouries