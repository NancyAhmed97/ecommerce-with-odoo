import React, { useEffect } from 'react'
import "./ProduuctsList.css"
import { Container, Row } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { getProducts } from './Network'
function ProduuctsList() {
    useEffect(() => {
        getProducts((success) => {
        //   setPage(success.next.slice(success.next.search('page') + 5));
        //   setProperties(success.results);
        //   dispatch(propertiesItem(success))
        },
          (fail) => {
            console.log(fail);
          }
        );
    
    
      }, [])
  return (
    <section className='properties_list_container'>
      <div className='section_title d-flex flex-column align-items-center'>
        <h2>Produucts</h2>
      </div>
       <Container fluid>
        <Row>
         {/* {properties && properties.slice(0, 6).map((item, i) => {
            return (
              <Col md={6} key={i} className="mb-3">
                <ItemContainer data={item} state={"properties"} activeState={"vertical"} />

              </Col>
            )
          })}
*/}

        </Row>
        <div className='text-center mt-3'>
          <div className='button_see_more'>
            <Link to="/properties">
        View More

            </Link>
          </div>
        </div>
      </Container> 
    </section >  )
}

export default ProduuctsList