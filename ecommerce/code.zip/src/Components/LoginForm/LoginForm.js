import React, { useState } from 'react'
import "./LoginForm.css"
import { Link } from 'react-router-dom'
import { Alert, Container, Row } from 'react-bootstrap'
function LoginForm() {
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [error, setError] = useState(false)


    const saveData=(e)=>{
       e.preventDefault();
if(!email||!password){
setError(true)
}else{

}
    }
    
    return (
        <section className='login_form_container'>
            <Container>
                <Row>
                    {error&&
                    
                    <Alert>
                        error
                    </Alert>
                    }
                    <div className='col-lg-6 offset-lg-3' >
                    <h2 >Login</h2>
                    <form onSubmit={saveData}>
                        <label >Email address *</label>
                        <input type='email'value={email} onChange={(e)=>{
                            setEmail(e.target.value)
                            setError(false)
                        }} />
                        <br />
                        <label>Password *</label>
                        <input type='password'value={password} onChange={(e)=>setPassword(e.target.value)} />
                        <br />

                        <Link to="/forget-password" className='forget_password'>Forget your Password</Link>
                        <br />

                        <button type='submit'>Sign In</button>
                    </form>
                    <div className='sign_up'>
                        <Link to="/sign-up">Or Create An Account</Link>
                    </div>
                    </div>
                </Row>
            </Container>
        </section>
    )
}

export default LoginForm