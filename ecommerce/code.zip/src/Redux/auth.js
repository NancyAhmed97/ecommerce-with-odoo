import { createSlice } from "@reduxjs/toolkit";

export const authSlice = createSlice({
  name: "auth",
  initialState: {
    user: {},
    authorization:'f03d2aba9902f38eb0925cbd66ee0a5cb096d0ec'
  },
  reducers: {
    login: (state, action) => {
      state.user = action.payload;
    },
    authorizationStatee:(state,action)=>{
        state.authorization = action.payload;

    },
    logout: (state, action) => {
      state.user = {};
    },
  },
});

export const { login } = authSlice.actions;
export const { logout } = authSlice.actions;

export default authSlice.reducer;
