import React from 'react'
import LoginForm from '../Components/LoginForm/LoginForm'

function Login() {
  return (
    <div>
        <LoginForm/>
    </div>
  )
}

export default Login