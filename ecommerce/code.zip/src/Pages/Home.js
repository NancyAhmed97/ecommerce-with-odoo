import React, { useEffect } from 'react'
import ProduuctsList from '../Components/ProduuctsList/ProduuctsList'
import axios from 'axios'
import Catigouries from '../Components/Catigouries/Catigouries'

function Home() {
  useEffect(() => {

    axios({
      method: "get",
      url: 'https://q8coders-staging-8077346.dev.odoo.com/product-details/',
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS,DELETE,PUT",
        'Authorization': 'f03d2aba9902f38eb0925cbd66ee0a5cb096d0ec',
      },

    }).then((res) => { console.log(res) }).catch((err) => console.log(err))
  }, [])

  return (
    <div>
      <Catigouries />
    </div>
  )
}

export default Home