import React from 'react'
import FavoritContainer from '../Components/FavoritContainer/FavoritContainer'

function Favorits() {
  return (
    <div>
        <FavoritContainer/>
    </div>
  )
}

export default Favorits