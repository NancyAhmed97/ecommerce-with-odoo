import React from 'react'
import SignupForm from '../Components/SignupForm/SignupForm'

function Signup() {
  return (
    <div>
        <SignupForm/>
    </div>
  )
}

export default Signup