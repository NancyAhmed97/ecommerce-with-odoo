import React from 'react'
import MyOrdersContainer from '../Components/MyOrdersContainer/MyOrdersContainer'

function MyOrders() {
  return (
    <div>
        <MyOrdersContainer/>
        
        
    </div>
  )
}

export default MyOrders