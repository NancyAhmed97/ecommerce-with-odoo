import React from 'react'
import CartContainer from '../Components/CartContainer/CartContainer'
import { Col, Container, Row } from 'react-bootstrap'

function Cart() {
  return (
    <div style={{background:"#f6f9fc"}}>
{/* <Navbar/> */}
<Container>
    <Row>
        <Col md={8} >
        <CartContainer/>
        <CartContainer/>
        <CartContainer/>
        <CartContainer/>
        <CartContainer/>
        <CartContainer/>


            </Col>  
            <Col md={4} >

            </Col>  
            
             </Row>
</Container>
{/* <Footer/> */}

    </div>
  )
}

export default Cart