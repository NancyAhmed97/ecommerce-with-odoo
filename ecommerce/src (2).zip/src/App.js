import RoutesPage from './RoutesPage';
import "./App.css"
import { useEffect } from 'react';
import ApiTest from './Pages/ApiTest';
function App() {
  useEffect(() => {
// Authorization:f03d2aba9902f38eb0925cbd66ee0a5cb096d0ec
  }, [])
  
  return (
<>
<RoutesPage/>
</>
  );
}

export default App;
