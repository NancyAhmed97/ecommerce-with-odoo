import React from 'react'
import ForgetForm from '../Components/ForgetForm/ForgetForm'

function ForgetPassword() {
  return (
    <div>
      <ForgetForm/>
    </div>
  )
}

export default ForgetPassword
