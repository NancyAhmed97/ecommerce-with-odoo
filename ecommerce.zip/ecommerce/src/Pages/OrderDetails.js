import React from 'react'
import OrderDetailsContainer from '../Components/OrderDetailsContainer/OrderDetailsContainer'
function OrderDetails() {
  return (
    <div>
      <OrderDetailsContainer/>
    </div>
  )
}

export default OrderDetails