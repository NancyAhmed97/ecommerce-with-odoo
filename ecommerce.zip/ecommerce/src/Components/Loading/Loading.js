import React from 'react'
import './Loading.css'
function Loading() {
  return (
    <div className='loading_container'>

    </div>
  )
}

export default Loading
