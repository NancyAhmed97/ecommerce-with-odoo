import React from "react";
import { Col, Container, Row } from "react-bootstrap";

function CategoyList() {
  return (
    <div className="categoy_filteration pl pr">
      <Container  classNameName="p-0 m-0">
        <Row classNameName="p-0 m-0">
          <Col className="p-0" md={4}>
            jdfhdsfjk
          </Col>
          <Col className="p-0" md={4}>
            jdfhdsfjk
          </Col>   <Col className="p-0" md={4}>
            jdfhdsfjk
          </Col>   <Col className="p-0" md={4}>
            jdfhdsfjk
          </Col>   <Col className="p-0" md={4}>
            jdfhdsfjk
          </Col>
        </Row>{" "}
        -
      </Container>{" "}
    </div>
  );
}

export default CategoyList;
